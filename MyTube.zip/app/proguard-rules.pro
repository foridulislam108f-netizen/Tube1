# My Tube keeps default rules; minification is disabled for debug builds.
