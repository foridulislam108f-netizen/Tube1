package com.tube1.app.ui.menu

import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.util.TypedValue
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.tube1.app.BuildConfig
import com.tube1.app.R
import com.tube1.app.data.Countries
import com.tube1.app.data.YtRepository
import com.tube1.app.databinding.FragmentMenuBinding
import com.tube1.app.util.AppPrefs
import com.tube1.app.util.BackupManager
import com.tube1.app.util.UpdateChecker
import com.tube1.app.util.Themes
import kotlinx.coroutines.launch

class MenuFragment : Fragment() {

    private var _binding: FragmentMenuBinding? = null
    private val binding get() = _binding!!

    private val importLauncher =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            if (uri != null) doImport(uri)
        }

    private val exportLauncher =
        registerForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
            if (uri != null) doExport(uri)
        }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentMenuBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding.rowCountry.setOnClickListener { showCountryPicker() }
        // Settings now live on their own full pages (general / video / music)
        // instead of cramped bottom sheets.
        binding.rowSettings.setOnClickListener {
            SettingsPageActivity.start(requireContext(), SettingsPageActivity.TYPE_GENERAL)
        }
        binding.rowVideoSettings.setOnClickListener {
            SettingsPageActivity.start(requireContext(), SettingsPageActivity.TYPE_VIDEO)
        }
        binding.rowMusicSettings.setOnClickListener {
            SettingsPageActivity.start(requireContext(), SettingsPageActivity.TYPE_MUSIC)
        }
        binding.rowCheckUpdate.setOnClickListener { checkForUpdate() }
        // Import / export now live together in their own backup submenu
        // (clear data moved into the general Settings page).
        binding.rowBackup.setOnClickListener { showBackupSheet() }
        binding.rowAbout.setOnClickListener { showAbout() }

        binding.version.text = getString(R.string.version_fmt, BuildConfig.VERSION_NAME)
    }

    override fun onResume() {
        super.onResume()
        val country = AppPrefs.countryOrDefault
        binding.countryValue.text = "${Countries.flagOf(country)} ${Countries.nameOf(country)}"
    }

    // ----- generic sheet plumbing -----

    private fun dp(value: Int): Int = TypedValue.applyDimension(
        TypedValue.COMPLEX_UNIT_DIP, value.toFloat(), resources.displayMetrics
    ).toInt()

    private fun sheetRoot(): LinearLayout = LinearLayout(requireContext()).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(20), dp(16), dp(20), dp(28))
    }

    private fun sheetTitle(text: String): TextView = TextView(requireContext()).apply {
        this.text = text
        textSize = 18f
        setTextColor(Themes.onSurfaceColor(requireContext()))
        setTypeface(null, Typeface.BOLD)
    }

    private fun sheetMenuRow(mainLabel: String, valueLabel: String, onClick: () -> Unit): LinearLayout =
        LinearLayout(requireContext()).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = android.view.Gravity.CENTER_VERTICAL
            setPadding(dp(14), dp(14), dp(14), dp(14))
            background = GradientDrawable().apply {
                cornerRadius = dp(12).toFloat()
                setColor(Themes.elevatedColor(requireContext()))
            }
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
            ).also { it.topMargin = dp(10) }
            setOnClickListener { onClick() }

            addView(
                TextView(requireContext()).apply {
                    text = mainLabel
                    textSize = 15f
                    setTextColor(Themes.onSurfaceColor(requireContext()))
                    setTypeface(null, Typeface.BOLD)
                    layoutParams = LinearLayout.LayoutParams(
                        0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f
                    )
                }
            )
            addView(
                TextView(requireContext()).apply {
                    text = valueLabel
                    textSize = 13f
                    maxLines = 1
                    ellipsize = android.text.TextUtils.TruncateAt.END
                    setTextColor(Themes.onSurfaceVariantColor(requireContext()))
                    layoutParams = LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT
                    ).also { it.marginEnd = dp(6) }
                }
            )
        }

    private fun showSheet(sheet: BottomSheetDialog, root: LinearLayout, peekDp: Int = 420) {
        val scroll = android.widget.ScrollView(requireContext()).apply { addView(root) }
        sheet.setContentView(scroll)
        sheet.behavior.peekHeight = dp(peekDp)
        sheet.show()
    }

    // ----- Backup / restore submenu -----

    /** Dedicated import/export submenu: one menu entry, one sheet. */
    private fun showBackupSheet() {
        val sheet = BottomSheetDialog(requireContext())
        val root = sheetRoot()
        root.addView(sheetTitle(getString(R.string.menu_backup_restore)))

        root.addView(
            sheetMenuRow(getString(R.string.menu_import), "") {
                runCatching {
                    importLauncher.launch(arrayOf("application/json"))
                }
            }
        )
        root.addView(
            sheetMenuRow(getString(R.string.menu_export), "") {
                runCatching {
                    exportLauncher.launch("mytube-backup.json")
                }
            }
        )
        showSheet(sheet, root, peekDp = 240)
    }

    // ----- Country -----

    private fun showCountryPicker() {
        val names = Countries.all.map { "${Countries.flagOf(it.code)} ${it.name}" }.toTypedArray()
        val current = Countries.all.indexOfFirst { it.code == AppPrefs.countryOrDefault }
        AlertDialog.Builder(requireContext())
            .setTitle(R.string.change_country)
            .setSingleChoiceItems(names, if (current >= 0) current else 0) { dialog, which ->
                val country = Countries.all[which]
                AppPrefs.country = country.code
                viewLifecycleOwner.lifecycleScope.launch {
                    YtRepository.applyCountry(country.code)
                }
                Toast.makeText(
                    requireContext(),
                    getString(R.string.country_changed, Countries.nameOf(country.code)),
                    Toast.LENGTH_SHORT
                ).show()
                binding.countryValue.text =
                    "${Countries.flagOf(country.code)} ${Countries.nameOf(country.code)}"
                dialog.dismiss()
            }
            .setNegativeButton(android.R.string.cancel, null)
            .show()
    }

    // ----- Import / export -----

    private fun doImport(uri: Uri) {
        val ctx = context ?: return
        val act = activity
        viewLifecycleOwner.lifecycleScope.launch {
            val ok = BackupManager.importFrom(ctx, uri)
            // The stored theme may have changed: re-apply the night mode and
            // refresh this screen right away when the visual prefs moved.
            Themes.applyDefaultNightMode()
            act?.let { Themes.recreateIfNeeded(it) }
            Toast.makeText(
                ctx,
                if (ok) R.string.import_done else R.string.import_failed,
                Toast.LENGTH_SHORT
            ).show()
        }
    }

    private fun doExport(uri: Uri) {
        val ctx = context ?: return
        viewLifecycleOwner.lifecycleScope.launch {
            val ok = BackupManager.exportTo(ctx, uri)
            Toast.makeText(
                ctx,
                if (ok) R.string.export_done else R.string.export_failed,
                Toast.LENGTH_SHORT
            ).show()
        }
    }

    // ----- Update check (GitHub releases of this app's own repo) -----

    private fun checkForUpdate() {
        val ctx = context ?: return
        Toast.makeText(ctx, R.string.checking_update, Toast.LENGTH_SHORT).show()
        viewLifecycleOwner.lifecycleScope.launch {
            val release = UpdateChecker.fetchLatest()
            when {
                release != null && UpdateChecker.isNewer(BuildConfig.VERSION_NAME, release.tag) ->
                    showUpdateDialog(release)
                release != null ->
                    Toast.makeText(ctx, R.string.up_to_date, Toast.LENGTH_SHORT).show()
                else ->
                    Toast.makeText(ctx, R.string.update_check_failed, Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun showUpdateDialog(release: UpdateChecker.Release) {
        val ctx = context ?: return
        val body = release.body.ifBlank {
            "Version ${release.tag.removePrefix("v")} is available."
        }
        AlertDialog.Builder(ctx)
            .setTitle(getString(R.string.update_available_title) + " · ${release.tag.removePrefix("v")}")
            .setMessage(body)
            .setPositiveButton(R.string.update_download) { _, _ ->
                UpdateChecker.openDownload(ctx, release)
            }
            .setNegativeButton(R.string.later, null)
            .show()
    }

    private fun showAbout() {
        AlertDialog.Builder(requireContext())
            .setTitle(R.string.app_name)
            .setMessage(getString(R.string.about_text))
            .setPositiveButton(android.R.string.ok, null)
            .show()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
