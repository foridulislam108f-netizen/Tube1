package com.tube1.app.ui.player

import android.content.Context
import android.content.Intent
import android.content.pm.ActivityInfo
import android.content.res.Configuration
import android.media.AudioManager
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.method.LinkMovementMethod
import android.util.Rational
import android.util.TypedValue
import android.view.GestureDetector
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.core.view.isVisible
import androidx.core.view.updateLayoutParams
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import androidx.media3.ui.R as Media3R
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.tube1.app.R
import com.tube1.app.data.CommentsPage
import com.tube1.app.data.LocalStore
import com.tube1.app.data.YtRepository
import com.tube1.app.databinding.ActivityPlayerBinding
import com.tube1.app.download.DownloadCenter
import com.tube1.app.playback.PlaybackCenter
import com.tube1.app.playback.QueueEntry
import com.tube1.app.playback.StreamCatalog
import com.tube1.app.playback.effectiveHeight
import com.tube1.app.playback.toVideoEntry
import com.tube1.app.ui.channel.ChannelActivity
import com.tube1.app.ui.common.CommentAdapter
import com.tube1.app.ui.common.VideoAdapter
import com.tube1.app.ui.common.toQueueEntry
import com.tube1.app.ui.common.toUiModel
import com.tube1.app.util.AppPrefs
import com.tube1.app.util.Formatters
import com.tube1.app.util.Avatars
import com.tube1.app.util.PanelTransitions
import com.tube1.app.util.Themes
import com.tube1.app.util.Thumbs
import coil.load
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch

/**
 * YouTube-style watch page: standard 16:9 player on top, title, a foldable
 * description card (views · date, tap to expand), channel row with
 * subscribe, action pills (favorite / share / download / background audio /
 * PiP), a comments card that opens a full comments sheet, and related
 * videos below. Quality, playback
 * speed and the dubbing audio track live inside the player's gear menu.
 * A swipe down on the video shrinks playback into the mini player.
 */
@OptIn(UnstableApi::class)
class PlayerActivity : AppCompatActivity() {

    private lateinit var binding: ActivityPlayerBinding
    private lateinit var relatedAdapter: VideoAdapter
    private var channelSubCount: Long = -1L

    private var swipeTriggered = false
    private lateinit var gestureDetector: GestureDetector
    private var gestureTracking = false
    private var gestureStartedInLandscape = false
    private var portraitGestureRejected = false
    private var gestureStartVolume = 0
    private var gestureStartBrightness = 0.5f
    private var gestureAxis = PlayerGestureMath.Axis.NONE
    private var gestureStartPosition = 0L
    private var pendingSeekTarget: Long? = null
    private val hideGestureFeedback = Runnable { binding.gestureFeedback.isVisible = false }
    private var retiringPip = false

    /** Mirrors the built-in controller's visibility (gear / seek controls). */
    private var controllerVisible = false

    // ----- Description (fold / unfold) -----
    private var descExpanded = false
    private var hasDescPanel = false
    private var descBoundFor: String? = null

    // ----- Comments -----
    private var commentsFor: String? = null
    private var commentsPage: CommentsPage? = null
    private var commentsJob: Job? = null

    private val playbackListener = object : PlaybackCenter.Listener {
        override fun onItemChanged(entry: QueueEntry?) {
            updateQueueControls()
            if (entry != null && entry.url != loadedUrl) {
                loadedUrl = entry.url
                bind(entry)
            }
        }

        override fun onQueueChanged() = updateQueueControls()
        override fun onSleepTimerExpired() { finish() }
        override fun onSleepTimerChanged() {
            binding.actionTimerLabel.text = com.tube1.app.ui.music.SleepTimerSheet.buttonLabel(this@PlayerActivity)
            binding.actionTimer.contentDescription = com.tube1.app.ui.music.SleepTimerSheet.accessibilityLabel(this@PlayerActivity)
        }

        override fun onPlaybackStateChanged(isPlaying: Boolean) = updateQueueControls()

        override fun onVideoFrameRendered() {
            binding.errorView.isVisible = false
            binding.loading.isVisible = false
        }

        override fun onResolvingChanged(isResolving: Boolean) {
            updateQueueControls()
            binding.loading.isVisible = isResolving && !binding.errorView.isVisible
        }

        override fun onCatalogReady() {
            updateQueueControls()
            bindCatalog()
        }

        override fun onError(message: String) {
            binding.loading.isVisible = false
            binding.errorText.text = message
            binding.errorView.isVisible = true
        }

        override fun onLiveContentBlocked() {
            Toast.makeText(this@PlayerActivity, R.string.live_not_supported, Toast.LENGTH_SHORT).show()
            finish()
        }

        override fun onFavoriteChanged(url: String, isFavorite: Boolean) = updateFavoriteUi()

        override fun onAudioOnlyChanged(audioOnly: Boolean) = bindCatalog()

        override fun onNotice(message: String) {
            Toast.makeText(this@PlayerActivity, message, Toast.LENGTH_SHORT).show()
        }
    }

    private var loadedUrl: String? = null

    private val downloadHandler = Handler(Looper.getMainLooper())

    override fun onCreate(savedInstanceState: Bundle?) {
        Themes.apply(this)
        super.onCreate(savedInstanceState)
        // A fresh watch page must not leave the previous pinned Activity behind.
        PlaybackCenter.closePreviousPip()

        // Expands UP out of the mini player (and collapses back down).
        PanelTransitions.install(this)

        // Edge-to-edge from the very first frame — THE punch-hole fix:
        // LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES alone only lets the
        // WINDOW cover the cutout area; with the default decor-fits-system-
        // windows behaviour the framework still pads the content away from
        // the cutout, so the notch stayed a black band in fullscreen.
        // Going fully edge-to-edge + SHORT_EDGES lets the video really render
        // under the punch-hole in every scale mode (insets are then applied
        // manually to the overlay buttons below).
        WindowCompat.setDecorFitsSystemWindows(window, false)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            window.attributes = window.attributes.apply {
                layoutInDisplayCutoutMode =
                    WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            }
        }

        binding = ActivityPlayerBinding.inflate(layoutInflater)
        setContentView(binding.root)

        applyWindowInsets()

        // Watching a video should keep the screen on.
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        // The fullscreen + scale buttons only appear together with the
        // player's own controls (gear / seek bar), like the official app.
        binding.fullscreenButton.isVisible = false
        binding.scaleButton.isVisible = false
        // Explicit object: a lambda would be ambiguous between the two
        // setControllerVisibilityListener overloads.
        binding.playerView.setControllerVisibilityListener(
            object : PlayerView.ControllerVisibilityListener {
                override fun onVisibilityChanged(visibility: Int) {
                    controllerVisible = visibility == View.VISIBLE
                    updateQueueControls()
                    syncFullscreenButtonVisibility()
                }
            }
        )

        // Watch-page chrome that depends on the resolved catalog: the action
        // pills and the subscribe button only appear once the video is
        // actually loaded (they used to flash in with placeholder labels
        // the moment the screen opened).
        binding.actionRow.isVisible = false
        binding.subscribeButton.isVisible = false

        // Foldable description + comments entry (both appear once the
        // video's catalog has loaded).
        binding.description.setLinkTextColor(Themes.accentColor(this))
        binding.titleBar.setOnClickListener { toggleDescription() }
        binding.commentsCard.setOnClickListener { openComments() }

        relatedAdapter = VideoAdapter(onClick = { model ->
            // Play inside this page so swipe/mini flow keeps working.
            val entry = model.toQueueEntry()
            PlaybackCenter.playVideo(entry)
        })
        binding.relatedList.layoutManager = LinearLayoutManager(this)
        binding.relatedList.adapter = relatedAdapter

        binding.retryButton.setOnClickListener { retry() }
        // Same collapse action as NowPlayingActivity: keep the shared queue/player alive.
        binding.backButton.setOnClickListener { finish() }

        binding.actionFavorite.setOnClickListener { toggleFavorite() }
        binding.actionPlaylist.setOnClickListener { showPlaylistSheet() }
        binding.actionShare.setOnClickListener { shareVideo() }
        binding.actionDownload.setOnClickListener { onDownloadClicked() }
        binding.actionTimerLabel.text = com.tube1.app.ui.music.SleepTimerSheet.buttonLabel(this)
        binding.actionTimer.setOnClickListener {
            com.tube1.app.ui.music.SleepTimerSheet(this).show()
        }
        binding.actionPip.setOnClickListener { enterPipOrToast() }
        binding.modeSwitch.setOnClickListener { openAudioView() }
        binding.playerView.setShowRewindButton(false)
        binding.playerView.setShowFastForwardButton(false)
        binding.queuePrevious.setOnClickListener {
            PlaybackCenter.previous()
            binding.playerView.showController()
        }
        binding.queueNext.setOnClickListener {
            PlaybackCenter.next()
            binding.playerView.showController()
        }
        binding.queuePlayPause.setOnClickListener {
            PlaybackCenter.togglePlayPause()
            binding.playerView.showController()
            updateQueueControls()
        }

        binding.channelInfo.setOnClickListener { openChannel() }
        binding.subscribeButton.setOnClickListener { toggleSubscribe() }

        // Fullscreen toggle: portrait <-> landscape without restarting the activity.
        binding.fullscreenButton.setOnClickListener { toggleFullscreen() }

        // Fullscreen scale mode: Fit -> Crop (fills the screen) -> Stretch.
        binding.scaleButton.setOnClickListener { cycleScaleMode() }
        applyScaleMode()

        gestureDetector = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onDown(e: MotionEvent): Boolean {
                swipeTriggered = false
                gestureAxis = PlayerGestureMath.Axis.NONE
                portraitGestureRejected = false
                gestureStartPosition = PlaybackCenter.positionMs
                pendingSeekTarget = null
                val audio = getSystemService(Context.AUDIO_SERVICE) as AudioManager
                gestureStartVolume = audio.getStreamVolume(AudioManager.STREAM_MUSIC)
                gestureStartBrightness = window.attributes.screenBrightness.takeIf { it >= 0f }
                    ?: (android.provider.Settings.System.getInt(contentResolver,
                        android.provider.Settings.System.SCREEN_BRIGHTNESS, 128) / 255f)
                return true
            }

            override fun onSingleTapConfirmed(e: MotionEvent): Boolean {
                // Right after a double-tap seek, every further tap keeps seeking
                // 10 s (left half back, right half forward). Otherwise a single
                // tap just shows / hides the controls.
                if (canSeekFromVideoSurface() &&
                    e.eventTime - lastSeekTapTime < RAPID_TAP_WINDOW_MS
                ) {
                    tapSeek(e, doubleTapEvent = false)
                    return true
                }
                if (binding.playerView.isControllerFullyVisible) binding.playerView.hideController()
                else binding.playerView.showController()
                return true
            }

            override fun onDoubleTap(e: MotionEvent): Boolean {
                // Preserve intentional double-tap seeks in both orientations.
                if (!canSeekFromVideoSurface()) return true
                tapSeek(e, doubleTapEvent = true)
                return true
            }

            override fun onScroll(e1: MotionEvent?, e2: MotionEvent, dx: Float, dy: Float): Boolean {
                val start = e1 ?: return false
                val totalY = start.y - e2.y
                val totalX = e2.x - start.x
                if (portraitGestureRejected) return true
                if (gestureAxis == PlayerGestureMath.Axis.NONE) {
                    gestureAxis = PlayerGestureMath.chooseAxis(totalX, totalY, dp(14).toFloat())
                    if (PlayerGestureMath.rejectAmbiguousPortraitMovement(
                            gestureStartedInLandscape, totalX, totalY, dp(14).toFloat())) {
                        portraitGestureRejected = true
                        return true
                    }
                    if (gestureAxis != PlayerGestureMath.Axis.NONE) {
                        swipeTriggered = true
                    }
                }
                if (gestureAxis == PlayerGestureMath.Axis.NONE) return true
                if (gestureAxis == PlayerGestureMath.Axis.HORIZONTAL) {
                    // Still consume this gesture: dragging into the bar must not
                    // transfer ownership or synthesize a new seek-bar ACTION_DOWN.
                    if (!canSeekFromVideoSurface()) return true
                    val pixelsPerTenSeconds = dp(120).toFloat().coerceAtLeast(1f)
                    pendingSeekTarget = PlayerGestureMath.horizontalSeekTarget(
                        gestureStartPosition, PlaybackCenter.durationMs, totalX, pixelsPerTenSeconds
                    )
                    showGestureFeedback(formatGestureSeek(pendingSeekTarget!!))
                    return true
                }
                val width = binding.playerView.width
                // The center retains swipe-down-to-minimize; sides adjust media levels.
                if (start.x > width * 0.35f && start.x < width * 0.65f) {
                    if (totalY < -dp(100)) finish()
                    return true
                }
                // Side brightness and volume adjustments are landscape only.
                if (resources.configuration.orientation != Configuration.ORIENTATION_LANDSCAPE) return true
                val fraction = totalY / (binding.playerView.height * 0.75f).coerceAtLeast(1f)
                if (start.x >= width / 2f) {
                    val audio = getSystemService(Context.AUDIO_SERVICE) as AudioManager
                    val max = audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
                    val volume = PlayerGestureMath.volume(gestureStartVolume, fraction, max)
                    try { audio.setStreamVolume(AudioManager.STREAM_MUSIC, volume, 0) }
                    catch (_: SecurityException) { return true }
                    showGestureFeedback(getString(R.string.gesture_volume, if (max > 0) volume * 100 / max else 0))
                } else {
                    val brightness = PlayerGestureMath.brightness(gestureStartBrightness, fraction)
                    window.attributes = window.attributes.apply { screenBrightness = brightness }
                    showGestureFeedback(getString(R.string.gesture_brightness, (brightness * 100).toInt()))
                }
                return true
            }
        })

        hookGearMenu()

        applyOrientation(resources.configuration)

        if (intent.getBooleanExtra(EXTRA_ATTACH, false) && PlaybackCenter.hasMedia) {
            loadedUrl = PlaybackCenter.currentEntry?.url
            PlaybackCenter.currentEntry?.let(::bind)
            bindCatalog()
        } else {
            val entry = entryFromIntent()
            if (entry == null) {
                finish()
                return
            }
            if (PlaybackCenter.currentEntry?.url == entry.url && PlaybackCenter.mode == PlaybackCenter.Mode.VIDEO) {
                PlaybackCenter.switchBackToVideo()
                loadedUrl = entry.url
                bind(entry)
                bindCatalog()
            } else {
                PlaybackCenter.playVideo(entry)
            }
        }
    }

    /** Keep unavailable queue actions visible but dimmed, never replace them with seek. */
    private fun updateQueueControls() {
        if (!::binding.isInitialized) return
        val player = PlaybackCenter.sessionPlayer
        listOf(
            binding.queuePrevious to Player.COMMAND_SEEK_TO_PREVIOUS,
            binding.queueNext to Player.COMMAND_SEEK_TO_NEXT_MEDIA_ITEM
        ).forEach { (button, command) ->
            button.isEnabled = player.isCommandAvailable(command)
            button.alpha = if (button.isEnabled) 1f else 0.35f
        }
        val playing = player.playWhenReady && player.playbackState != Player.STATE_ENDED
        binding.queuePlayPause.setImageResource(if (playing) R.drawable.ic_pause else R.drawable.ic_play_arrow)
        binding.queuePlayPause.contentDescription = getString(
            if (playing) Media3R.string.exo_controls_pause_description else Media3R.string.exo_controls_play_description)
        binding.transportControls.isVisible = controllerVisible && !isInPictureInPictureMode
    }

    private fun openAudioView() {
        PlaybackCenter.switchToAudioOnly()
        com.tube1.app.ui.music.NowPlayingActivity.start(this)
        finish()
    }

    /** Time of the last tap-seek: taps arriving soon after keep seeking 10 s each. */
    private var lastSeekTapTime = 0L
    private var rapidSeekBase = 0L
    private var rapidTapCount = 0
    private var rapidForward = true

    /**
     * Rapid taps on one side seek by a growing distance: 2 taps = 10 s,
     * 3 = 20 s, 4 = 30 s, 5 = 40 s ... counted from where the run started.
     */
    private fun tapSeek(e: MotionEvent, doubleTapEvent: Boolean) {
        val forward = e.x >= binding.playerView.width / 2f
        val rapid = rapidTapCount > 0 && forward == rapidForward &&
            e.eventTime - lastSeekTapTime < RAPID_TAP_WINDOW_MS
        if (!rapid) {
            rapidSeekBase = PlaybackCenter.positionMs
            rapidTapCount = 0
            rapidForward = forward
        }
        // A double-tap event is two taps at once.
        rapidTapCount += if (doubleTapEvent) 2 else 1
        lastSeekTapTime = e.eventTime
        val pos = PlayerGestureMath.tapSeekTarget(
            rapidSeekBase, PlaybackCenter.durationMs, rapidTapCount, forward
        )
        PlaybackCenter.seekTo(pos)
        val seconds = PlayerGestureMath.tapSeekTotalMs(rapidTapCount) / 1_000L
        showGestureFeedback(if (forward) "+$seconds s" else "−$seconds s")
    }

    private fun showGestureFeedback(text: String) {
        binding.gestureFeedback.text = text
        binding.gestureFeedback.isVisible = true
        downloadHandler.removeCallbacks(hideGestureFeedback)
        downloadHandler.postDelayed(hideGestureFeedback, 900)
    }

    private fun formatGestureSeek(positionMs: Long): String {
        val seconds = positionMs / 1_000L
        return "${seconds / 60}:${(seconds % 60).toString().padStart(2, '0')}"
    }

    private fun canSeekFromVideoSurface(): Boolean = PlayerGestureMath.canSeekVideoSurface(
        gestureStartedInLandscape,
        resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE
    )

    // Dispatch above the controller's empty scrim, but leave real buttons and the seek bar alone.
    override fun dispatchTouchEvent(event: MotionEvent): Boolean {
        if (!::gestureDetector.isInitialized || isInPictureInPictureMode) return super.dispatchTouchEvent(event)
        val point = IntArray(2)
        binding.playerView.getLocationOnScreen(point)
        val x = event.rawX - point[0]
        val y = event.rawY - point[1]
        if (event.actionMasked == MotionEvent.ACTION_DOWN) {
            portraitGestureRejected = false
            gestureStartedInLandscape = resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE
            val inside = x >= 0 && x < binding.playerView.width && y >= 0 && y < binding.playerView.height
            gestureTracking = inside && !hitsPlayerControl(binding.root, event.rawX.toInt(), event.rawY.toInt())
        }
        if (gestureTracking) {
            val local = MotionEvent.obtain(event)
            local.setLocation(x, y)
            if (!gestureStartedInLandscape && (event.pointerCount > 1 ||
                    event.actionMasked == MotionEvent.ACTION_POINTER_DOWN)) {
                local.action = MotionEvent.ACTION_CANCEL
                gestureDetector.onTouchEvent(local)
                portraitGestureRejected = true
                pendingSeekTarget = null
            } else if (!portraitGestureRejected) {
                gestureDetector.onTouchEvent(local)
            }
            local.recycle()
            if (event.actionMasked == MotionEvent.ACTION_UP || event.actionMasked == MotionEvent.ACTION_CANCEL) {
                if (event.actionMasked == MotionEvent.ACTION_UP && !portraitGestureRejected && canSeekFromVideoSurface()) {
                    pendingSeekTarget?.let(PlaybackCenter::seekTo)
                }
                pendingSeekTarget = null
                gestureTracking = false
            }
            return true
        }
        return super.dispatchTouchEvent(event)
    }

    private fun hitsPlayerControl(view: View, x: Int, y: Int): Boolean {
        if (!view.isShown) return false
        val rect = android.graphics.Rect()
        if (!view.getGlobalVisibleRect(rect) || !rect.contains(x, y)) return false
        if (view is DeliberateSeekTimeBar &&
            resources.configuration.orientation != Configuration.ORIENTATION_LANDSCAPE) {
            val location = IntArray(2)
            view.getLocationOnScreen(location)
            return view.hitsVisibleSeekBar((x - location[0]).toFloat(), (y - location[1]).toFloat())
        }
        if (view is android.widget.ImageButton || view is android.widget.Button ||
            view is androidx.media3.ui.DefaultTimeBar || view === binding.modeSwitch) return true
        if (view is ViewGroup) {
            for (i in 0 until view.childCount) if (hitsPlayerControl(view.getChildAt(i), x, y)) return true
        }
        return false
    }

    /**
     * Puts quality / speed / audio-track selection behind the gear button of
     * the player's built-in controller.
     */
    private fun hookGearMenu() {
        // The top gear opens the same quality / speed / audio-track sheet the old bottom gear did.
        binding.topSettingsButton.setOnClickListener { showVideoSettingsSheet() }
        // Keep the fullscreen button on the same row as the time text.
        val time = binding.playerView.findViewById<View>(Media3R.id.exo_time)
        time?.addOnLayoutChangeListener { _, _, _, _, _, _, _, _, _ -> alignFullscreenNextToGear() }
        binding.fullscreenButton.addOnLayoutChangeListener { _, _, _, _, _, _, _, _, _ ->
            alignFullscreenNextToGear()
        }
    }

    /** Vertically centres the fullscreen button on the time row (bottom-right corner). */
    private fun alignFullscreenNextToGear() {
        val time = binding.playerView.findViewById<View>(Media3R.id.exo_time) ?: return
        val fs = binding.fullscreenButton
        if (time.width == 0 || time.height == 0 || fs.width == 0 || !time.isShown) return
        val t = IntArray(2)
        val f = IntArray(2)
        time.getLocationInWindow(t)
        fs.getLocationInWindow(f)
        val baseTop = f[1] - fs.translationY
        val ty = (t[1] + time.height / 2f) - (baseTop + fs.height / 2f)
        if (kotlin.math.abs(ty - fs.translationY) > 0.5f) fs.translationY = ty
        if (fs.translationX != 0f) fs.translationX = 0f
    }

    /** All overlay buttons follow the built-in controller's visibility. */
    private fun syncFullscreenButtonVisibility() {
        val visible = !isInPictureInPictureMode && controllerVisible
        // Single-tap reveal and auto-hide apply to collapse just like transport.
        binding.backButton.isVisible = visible
        binding.transportControls.isVisible = visible
        binding.fullscreenButton.isVisible = visible
        binding.fullscreenButton.post { alignFullscreenNextToGear() }
        binding.modeSwitch.isVisible = visible
        binding.topSettingsButton.isVisible = visible
        binding.topScrim.isVisible = visible
        // Fit / Crop / Stretch is a fullscreen-only control: the portrait
        // box always shows the full frame, so the button stays hidden there.
        binding.scaleButton.isVisible = visible &&
            resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE
    }

    /** Latest top inset from the status bar / cutout (0 once bars are hidden). */
    private var lastTopInset = 0

    /**
     * Keeps the whole video visible on the portrait watch page: the player
     * box sits BELOW the status bar / punch-hole. The window being
     * edge-to-edge (needed for fullscreen) used to slide the video under
     * them, cutting off its top strip in normal mode. Landscape fullscreen
     * keeps topMargin 0 so the video still renders under the (hidden) bars
     * and the cutout — the punch-hole fullscreen fix. PiP gets 0 too (the
     * floating window has no insets).
     */
    private fun applyPlayerTopInset() {
        val landscape = resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE
        binding.playerView.updateLayoutParams<ConstraintLayout.LayoutParams> {
            topMargin = if (landscape || isInPictureInPictureMode) 0 else lastTopInset
        }
    }

    /**
     * Manual insets now that the window draws edge-to-edge: the overlay
     * buttons keep a safe distance from the status bar / cutout and the
     * page content clears the gesture bar.
     */
    private fun applyWindowInsets() {
        ViewCompat.setOnApplyWindowInsetsListener(binding.root) { root, insets ->
            val bars = insets.getInsets(
                WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout()
            )
            val rtl = root.layoutDirection == android.view.View.LAYOUT_DIRECTION_RTL
            val startInset = if (rtl) bars.right else bars.left
            val endInset = if (rtl) bars.left else bars.right

            binding.backButton.updateLayoutParams<ConstraintLayout.LayoutParams> {
                // Portrait playerView already clears the status bar; don't add it twice.
                topMargin = dp(4) + if (resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE) bars.top else 0
                marginStart = dp(4) + startInset
            }
            binding.fullscreenButton.updateLayoutParams<ConstraintLayout.LayoutParams> {
                marginEnd = endInset
                bottomMargin = 0
            }
            binding.topSettingsButton.updateLayoutParams<ConstraintLayout.LayoutParams> {
                topMargin = dp(4) + if (resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE) bars.top else 0
                marginEnd = endInset + dp(4)
            }
            binding.modeSwitch.updateLayoutParams<ConstraintLayout.LayoutParams> {
                topMargin = dp(4) + if (resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE) bars.top else 0
                marginEnd = 0
            }
            binding.scaleButton.updateLayoutParams<ConstraintLayout.LayoutParams> {
                topMargin = bars.top + dp(4)
                marginEnd = endInset
            }
            lastTopInset = bars.top
            applyPlayerTopInset()
            binding.scrollArea.setPadding(
                binding.scrollArea.paddingLeft,
                binding.scrollArea.paddingTop,
                binding.scrollArea.paddingRight,
                bars.bottom + dp(24)
            )
            insets
        }
    }

    /** Real fullscreen: hide status + navigation bars while landscape. */
    private fun applyImmersive(landscape: Boolean) {
        val controller = WindowCompat.getInsetsController(window, window.decorView)
        if (landscape) {
            controller.systemBarsBehavior =
                WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            controller.hide(WindowInsetsCompat.Type.systemBars())
        } else {
            controller.show(WindowInsetsCompat.Type.systemBars())
        }
    }

    // ----- Fullscreen scale mode -----

    /**
     * Applies the scale preference (fit / crop / stretch). It is a FULLSCREEN
     * setting: the portrait watch page is always RESIZE_MODE_FIT so no part
     * of the video is ever cropped inside the normal player box.
     */
    private fun applyScaleMode() {
        val landscape = resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE
        val mode = if (landscape) when (AppPrefs.fullscreenScale) {
            AppPrefs.SCALE_CROP -> AspectRatioFrameLayout.RESIZE_MODE_ZOOM
            AppPrefs.SCALE_STRETCH -> AspectRatioFrameLayout.RESIZE_MODE_FILL
            else -> AspectRatioFrameLayout.RESIZE_MODE_FIT
        } else {
            AspectRatioFrameLayout.RESIZE_MODE_FIT
        }
        binding.playerView.resizeMode = mode
    }

    /** Cycles Fit -> Crop -> Stretch and applies + persists the choice. */
    private fun cycleScaleMode() {
        val next = when (AppPrefs.fullscreenScale) {
            AppPrefs.SCALE_FIT -> AppPrefs.SCALE_CROP
            AppPrefs.SCALE_CROP -> AppPrefs.SCALE_STRETCH
            else -> AppPrefs.SCALE_FIT
        }
        AppPrefs.fullscreenScale = next
        applyScaleMode()
        val label = when (next) {
            AppPrefs.SCALE_CROP -> getString(R.string.scale_crop)
            AppPrefs.SCALE_STRETCH -> getString(R.string.scale_stretch)
            else -> getString(R.string.scale_fit)
        }
        Toast.makeText(this, label, Toast.LENGTH_SHORT).show()
    }

    private fun toggleFullscreen() {
        val landscape = resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE
        requestedOrientation = if (landscape) {
            ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
        } else {
            ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
        }
    }

    override fun onStart() {
        super.onStart()
        if (retiringPip || isFinishing) return
        PlaybackCenter.addListener(playbackListener)
        // A visible PiP activity may be STARTED/PAUSED, never RESUMED.
        PlaybackCenter.setPipState(binding.playerView, isInPictureInPictureMode, ::closeReplacedPip)
        PlaybackCenter.attachView(binding.playerView)
        updateQueueControls()
        // Playback can start resolving BEFORE this page is listening (Play
        // all / a playlist video starts the queue, then opens the page), so
        // pick the spinner state up here instead of missing it.
        binding.loading.isVisible = PlaybackCenter.isResolving && !binding.errorView.isVisible
        downloadHandler.post(downloadPoll)
    }

    override fun onResume() {
        super.onResume()
        if (retiringPip || isFinishing) return
        if (Themes.recreateIfNeeded(this)) return
        applyCloseTransition()
        PlaybackCenter.attachView(binding.playerView)
    }

    // ----- Close animation -----

    /**
     * Android 14+: registers the close animation once for this page. The
     * default activity-close animation slides the page sideways (left to
     * right on most devices), which reads wrong when the video is really
     * collapsing DOWN into the mini player at the bottom of the screen.
     */
    private fun applyCloseTransition() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.UPSIDE_DOWN_CAKE) return
        if (AppPrefs.animations) {
            overrideActivityTransition(OVERRIDE_TRANSITION_CLOSE, 0, R.anim.slide_down_out)
        } else {
            clearOverrideActivityTransition(OVERRIDE_TRANSITION_CLOSE)
        }
    }

    /**
     * Every way out of the watch page (swipe down, back button / gesture,
     * "play in background") collapses into the mini player, so all of them
     * slide down. Older Android has no per-activity registration: the
     * override has to be requested right after finish().
     */
    @Suppress("DEPRECATION")
    override fun finish() {
        super.finish()
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.UPSIDE_DOWN_CAKE && AppPrefs.animations) {
            overridePendingTransition(0, R.anim.slide_down_out)
        }
    }

    // Do NOT detach in onPause: Android/ROMs can pause us before delivering
    // the PiP-mode callback. PiP stays visible while paused and needs the
    // same TextureView output. Detach only once the activity is not visible.

    override fun onStop() {
        super.onStop()
        PlaybackCenter.detachView(binding.playerView)
        // A stopped/temporarily hidden pinned Activity still needs to be
        // reachable for replacement cleanup; only a real exit releases it.
        if (!isInPictureInPictureMode || isFinishing || retiringPip) {
            PlaybackCenter.setPipState(binding.playerView, false)
        }
        downloadHandler.removeCallbacks(downloadPoll)
        downloadHandler.removeCallbacks(hideGestureFeedback)
        PlaybackCenter.removeListener(playbackListener)
        // Return to sensor portrait so the next video starts the standard way.
        if (requestedOrientation != ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED) {
            requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        }
    }

    override fun onDestroy() {
        PlaybackCenter.setPipState(binding.playerView, false)
        PlaybackCenter.detachView(binding.playerView)
        super.onDestroy()
    }

    // ----- PiP -----

    private fun closeReplacedPip() {
        if (retiringPip) return
        retiringPip = true
        PlaybackCenter.removeListener(playbackListener)
        PlaybackCenter.detachView(binding.playerView)
        // Finish the pinned Activity itself, not just its surface or global flag.
        // Never stop/pause the shared engine: it is about to play the new item.
        finish()
    }

    override fun onUserLeaveHint() {
        super.onUserLeaveHint()
        if (retiringPip || isFinishing) return
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && PlaybackCenter.hasMedia &&
            PlaybackCenter.mode == PlaybackCenter.Mode.VIDEO && !PlaybackCenter.audioOnlyMode
        ) {
            enterPip()
        }
    }

    private fun enterPipOrToast() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            enterPip()
        } else {
            Toast.makeText(this, R.string.pip_unsupported, Toast.LENGTH_SHORT).show()
        }
    }

    private fun enterPip() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O || retiringPip || isFinishing) return
        try {
            enterPictureInPictureMode(
                android.app.PictureInPictureParams.Builder()
                    .setAspectRatio(Rational(16, 9))
                    .build()
            )
        } catch (e: Exception) {
            // Some ROMs throw when PiP is unavailable.
        }
    }

    override fun onPictureInPictureModeChanged(
        isInPictureInPictureMode: Boolean,
        newConfig: Configuration
    ) {
        super.onPictureInPictureModeChanged(isInPictureInPictureMode, newConfig)
        if (retiringPip || isFinishing) return
        PlaybackCenter.setPipState(binding.playerView, isInPictureInPictureMode, ::closeReplacedPip)
        // Recover ownership even if pause/configuration callbacks arrived
        // first. attachView is idempotent and uses the raw rendering player.
        if (isInPictureInPictureMode) PlaybackCenter.attachView(binding.playerView)
        binding.playerView.useController = !isInPictureInPictureMode
        applyOrientation(newConfig)
        if (!isInPictureInPictureMode) binding.playerView.showController()
    }

    private fun applyPipLayout() {
        // Both mode and configuration callbacks use this path: orientation
        // must never restore the watch page over the tiny PiP video output.
        binding.transportControls.isVisible = false
        binding.playerView.hideController()
        binding.backButton.isVisible = false
        binding.fullscreenButton.isVisible = false
        binding.scaleButton.isVisible = false
        binding.modeSwitch.isVisible = false
        binding.topSettingsButton.isVisible = false
        binding.topScrim.isVisible = false
        binding.gestureFeedback.isVisible = false
        binding.scrollArea.isVisible = false
        binding.loading.isVisible = false
        binding.errorView.isVisible = false
        binding.playerView.resizeMode = AspectRatioFrameLayout.RESIZE_MODE_FIT
        binding.playerView.updateLayoutParams<ConstraintLayout.LayoutParams> {
            height = ViewGroup.LayoutParams.MATCH_PARENT
            dimensionRatio = null
            topMargin = 0
        }
    }

    // ----- Orientation -----

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        applyOrientation(newConfig)
    }

    private fun applyOrientation(config: Configuration) {
        if (isInPictureInPictureMode) {
            applyPipLayout()
            return
        }
        val landscape = config.orientation == Configuration.ORIENTATION_LANDSCAPE
        if (!landscape) {
            // Do not carry a fullscreen-only brightness override back to portrait.
            window.attributes = window.attributes.apply {
                screenBrightness = WindowManager.LayoutParams.BRIGHTNESS_OVERRIDE_NONE
            }
            binding.gestureFeedback.isVisible = false
        }
        // This activity handles rotation without reinflating the controller.
        // Clear only the portrait bottom strip; restore Media3's original
        // background in landscape without changing seek layout or behavior.
        binding.playerView.findViewById<View>(Media3R.id.exo_bottom_bar)?.setBackgroundResource(
            if (landscape) Media3R.color.exo_bottom_bar_background else android.R.color.transparent
        )
        // The portrait-only dimension is also read by Media3's layout manager,
        // so resizing cannot put the old 52dp gap back. Apply it immediately
        // on rotation too, before the next controller size/layout callback.
        binding.playerView.findViewById<View>(Media3R.id.exo_progress)
            ?.updateLayoutParams<ViewGroup.MarginLayoutParams> {
                bottomMargin = resources.getDimensionPixelSize(Media3R.dimen.exo_styled_progress_margin_bottom)
            }
        // Keep settings clickable above the lowered 48dp seek touch target.
        // Empty transparent row space still passes touches through to the bar.
        // Restore the original zero Z/order for landscape controls.
        binding.playerView.findViewById<View>(Media3R.id.exo_bottom_bar)?.translationZ =
            if (landscape) 0f else dp(1).toFloat()
        binding.fullscreenButton.setImageResource(
            if (landscape) R.drawable.ic_fullscreen_exit else R.drawable.ic_fullscreen
        )
        // Landscape video = immersive: no notification bar, no nav bar, the
        // video fills the whole screen. Portrait restores normal system bars.
        applyImmersive(landscape)
        if (landscape) {
            binding.scrollArea.isVisible = false
            binding.playerView.updateLayoutParams<ConstraintLayout.LayoutParams> {
                height = ViewGroup.LayoutParams.MATCH_PARENT
                dimensionRatio = null
            }
        } else {
            binding.scrollArea.isVisible = true
            binding.playerView.updateLayoutParams<ConstraintLayout.LayoutParams> {
                height = 0
                dimensionRatio = "16:9"
            }
        }
        // Orientation-dependent state: the scale preference is
        // fullscreen-only and the portrait box needs its status-bar offset.
        applyScaleMode()
        applyPlayerTopInset()
        syncFullscreenButtonVisibility()
    }

    // ----- Binding -----

    private fun entryFromIntent(): QueueEntry? {
        val url = intent.getStringExtra(EXTRA_URL) ?: return null
        return QueueEntry(
            url = url,
            title = intent.getStringExtra(EXTRA_TITLE).orEmpty(),
            uploader = intent.getStringExtra(EXTRA_UPLOADER).orEmpty(),
            thumbnailUrl = intent.getStringExtra(EXTRA_THUMB).orEmpty(),
            durationSec = intent.getLongExtra(EXTRA_DURATION, 0L)
        )
    }

    private fun bind(entry: QueueEntry) {
        binding.errorView.isVisible = false
        binding.title.text = entry.title
        binding.views.text = ""
        binding.channelName.text = entry.uploader
        binding.channelSubs.text = ""
        binding.channelAvatar.setImageResource(0)
        loadChannelInfo()

        updateFavoriteUi()
        updateDownloadUi()

        // History + favourites may have changed, list them below.
        bindCatalog()
    }

    private fun bindCatalog() {
        val entry = PlaybackCenter.currentEntry ?: return
        val catalog = PlaybackCenter.catalog

        // Pills + subscribe stay hidden until the catalog (uploader info,
        // views, related list) has actually loaded for this video.
        binding.actionRow.isVisible = catalog != null

        if (catalog != null) {
            binding.title.text = catalog.name.ifBlank { entry.title }
            bindDescription(catalog, entry.url)
            maybeLoadComments(entry.url)
            binding.channelName.text = catalog.uploaderName.ifBlank { entry.uploader }
            if (catalog.uploaderAvatarUrl.isNotBlank()) {
                Thumbs.load(binding.channelAvatar, catalog.uploaderAvatarUrl)
            }
            relatedAdapter.submitList(catalog.related.map { it.toUiModel() })
        } else {
            // New video still resolving: nothing of the old one may linger.
            binding.descCard.isVisible = false
            binding.descChevron.isVisible = false
            descBoundFor = null
            resetComments()
        }
        updateSubscribeUi()
    }

    // ----- Description card -----

    /**
     * Views sit above the title (top-left). The upload date + description
     * live in a panel that opens when the title bar is tapped.
     */
    private fun bindDescription(catalog: StreamCatalog, url: String) {
        binding.views.text = catalog.viewCount.takeIf { it >= 0 }
            ?.let { getString(R.string.views_fmt, Formatters.formatViewCount(it)) }
            .orEmpty()

        // Already bound for this video (e.g. audio-only toggle): keep the
        // user's open / closed state instead of collapsing under them.
        if (descBoundFor == url) return
        descBoundFor = url
        descExpanded = false

        val text = CommentAdapter.bodyToText(catalog.description, catalog.descriptionIsHtml)
        val date = catalog.uploadDateText
        hasDescPanel = text.isNotBlank() || date.isNotBlank()
        binding.descDate.text = date
        binding.descDate.isVisible = date.isNotBlank()
        binding.description.text = text
        binding.description.isVisible = text.isNotBlank()
        binding.titleBar.isClickable = hasDescPanel
        binding.descChevron.isVisible = hasDescPanel
        applyDescriptionState(animate = false)
    }

    private fun toggleDescription() {
        if (!hasDescPanel) return
        descExpanded = !descExpanded
        applyDescriptionState(animate = true)
    }

    private fun applyDescriptionState(animate: Boolean) {
        val animated = animate && AppPrefs.animations
        if (animated) {
            android.transition.TransitionManager.beginDelayedTransition(
                binding.scrollContent,
                android.transition.ChangeBounds().apply { duration = 200 }
            )
        }
        binding.descCard.isVisible = descExpanded && hasDescPanel
        // Title: 2 lines when closed, full text when the panel is open.
        binding.title.maxLines = if (descExpanded) Int.MAX_VALUE else 2
        // Links only work while open: a link-enabled TextView swallows taps.
        binding.description.movementMethod =
            if (descExpanded) LinkMovementMethod.getInstance() else null
        val target = if (descExpanded) 0f else 180f
        if (animated) {
            binding.descChevron.animate().rotation(target).setDuration(200).start()
        } else {
            binding.descChevron.animate().cancel()
            binding.descChevron.rotation = target
        }
    }

    // ----- Comments card -----

    private fun resetComments() {
        commentsJob?.cancel()
        commentsJob = null
        commentsFor = null
        commentsPage = null
        binding.commentsCard.isVisible = false
    }

    /** Fetches the first comments page once per video for the preview card. */
    private fun maybeLoadComments(url: String) {
        // Downloaded files have no online comments.
        if (url.startsWith("file://")) {
            binding.commentsCard.isVisible = false
            return
        }
        binding.commentsCard.isVisible = true
        if (commentsFor == url) return
        commentsFor = url
        commentsPage = null
        binding.commentsCount.text = ""
        binding.commentsPreviewRow.isVisible = false
        binding.commentsStatus.setText(R.string.comments_loading)
        binding.commentsStatus.isVisible = true
        commentsJob?.cancel()
        commentsJob = lifecycleScope.launch {
            try {
                val page = YtRepository.comments(url)
                if (commentsFor != url) return@launch
                commentsPage = page
                bindCommentsPreview(page)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                if (commentsFor != url) return@launch
                // The sheet retries on open, so a tap on the card still works.
                binding.commentsStatus.setText(R.string.comments_error)
                binding.commentsStatus.isVisible = true
            }
        }
    }

    private fun bindCommentsPreview(page: CommentsPage) {
        binding.commentsCount.text =
            if (page.total > 0) Formatters.formatViewCount(page.total.toLong()) else ""
        when {
            page.disabled -> {
                binding.commentsPreviewRow.isVisible = false
                binding.commentsStatus.setText(R.string.comments_disabled)
                binding.commentsStatus.isVisible = true
            }
            page.items.isEmpty() -> {
                binding.commentsPreviewRow.isVisible = false
                binding.commentsStatus.setText(R.string.comments_empty)
                binding.commentsStatus.isVisible = true
            }
            else -> {
                val top = page.items.first()
                Avatars.load(binding.commentsPreviewAvatar, top.avatarUrl, top.author)
                binding.commentsPreviewText.text = CommentAdapter.commentText(top).toString()
                binding.commentsPreviewRow.isVisible = true
                binding.commentsStatus.isVisible = false
            }
        }
    }

    private fun openComments() {
        val url = PlaybackCenter.currentEntry?.url ?: return
        CommentsSheet(
            context = this,
            scope = lifecycleScope,
            videoUrl = url,
            initial = commentsPage,
            onLoaded = { loaded ->
                if (commentsFor == url) {
                    commentsPage = loaded
                    bindCommentsPreview(loaded)
                }
            }
        ).show()
    }

    private fun loadChannelInfo() {
        val uploaderUrl = PlaybackCenter.catalog?.uploaderUrl ?: return
        lifecycleScope.launch {
            try {
                val channel = YtRepository.channelInfo(uploaderUrl)
                channelSubCount = channel.subscriberCount
                binding.channelSubs.text =
                    getString(R.string.subscribers_fmt, Formatters.formatViewCount(channel.subscriberCount))
                updateSubscribeUi()
            } catch (e: Exception) {
                // Sub count is optional decoration; ignore failures.
            }
        }
    }

    private fun updateFavoriteUi() {
        val entry = PlaybackCenter.currentEntry ?: return
        val isFav = LocalStore.isFavorite(this, entry.url)
        binding.actionFavoriteIcon.setImageResource(
            if (isFav) R.drawable.ic_favorite else R.drawable.ic_favorite_border
        )
        binding.actionFavoriteIcon.setColorFilter(
            if (isFav) Themes.accentColor(this) else getColor(R.color.on_surface)
        )
        binding.actionFavoriteLabel.text =
            getString(if (isFav) R.string.saved_short else R.string.action_favorite)
    }

    // ----- Download pill -----

    private fun onDownloadClicked() {
        val entry = PlaybackCenter.currentEntry ?: return
        when {
            DownloadCenter.isDownloaded(this, entry.url) -> {
                // Already downloaded: offer to delete it right here instead of
                // sending the user to Library → Downloads.
                confirmDeleteDownload()
            }
            DownloadCenter.hasActiveDownload(this, entry.url) -> {
                com.tube1.app.ui.MainActivity.openDownloads(this)
            }
            else -> showDownloadSheet()
        }
    }

    /** Deletes every finished download record of the current video. */
    private fun confirmDeleteDownload() {
        val entry = PlaybackCenter.currentEntry ?: return
        AlertDialog.Builder(this)
            .setTitle(R.string.download_delete_confirm)
            .setMessage(entry.title)
            .setPositiveButton(android.R.string.ok) { _, _ ->
                DownloadCenter.recordsFor(this, entry.url).forEach { record ->
                    DownloadCenter.delete(this, record)
                }
                Toast.makeText(this, R.string.download_deleted, Toast.LENGTH_SHORT).show()
                updateDownloadUi()
            }
            .setNegativeButton(android.R.string.cancel, null)
            .show()
    }

    // ----- Add to playlist -----

    /** The current video as a storable entry (playlists reuse VideoEntry). */
    private fun currentVideoEntry(): com.tube1.app.data.VideoEntry? =
        PlaybackCenter.currentEntry?.toVideoEntry()

    /**
     * "Add to playlist" picker: every existing playlist (tapping one adds —
     * or removes, when the video is already in it) plus a "New playlist"
     * row that creates one on the spot.
     */
    private fun showPlaylistSheet() {
        val video = currentVideoEntry() ?: return
        val sheet = BottomSheetDialog(this)
        val root = sheetRoot()
        root.addView(sheetTitle(getString(R.string.playlist_sheet_title)))

        root.addView(
            sheetRow("+ " + getString(R.string.new_playlist), selected = false) {
                sheet.dismiss()
                showNewPlaylistDialog()
            }
        )

        val playlists = LocalStore.playlists(this)
        if (playlists.isEmpty()) {
            root.addView(hintRow(getString(R.string.playlist_sheet_empty)))
        } else {
            playlists.forEach { playlist ->
                val added = playlist.items.any { it.url == video.url }
                root.addView(
                    sheetMenuRow(
                        playlist.name,
                        if (added) getString(R.string.playlist_added) else ""
                    ) {
                        if (added) {
                            LocalStore.removeFromPlaylist(this, playlist.id, video.url)
                            Toast.makeText(
                                this,
                                getString(R.string.removed_from_playlist_fmt, playlist.name),
                                Toast.LENGTH_SHORT
                            ).show()
                        } else {
                            LocalStore.addToPlaylist(this, playlist.id, video)
                            Toast.makeText(
                                this,
                                getString(R.string.saved_to_playlist_fmt, playlist.name),
                                Toast.LENGTH_SHORT
                            ).show()
                        }
                        sheet.dismiss()
                    }
                )
            }
        }

        showSheet(sheet, root, peekDp = 380)
    }

    /** Name input dialog that creates a playlist and saves the video into it. */
    private fun showNewPlaylistDialog() {
        val video = currentVideoEntry() ?: return
        val input = android.widget.EditText(this).apply {
            hint = getString(R.string.new_playlist_hint)
            setSingleLine()
        }
        val container = android.widget.FrameLayout(this).apply {
            setPadding(dp(24), dp(8), dp(24), 0)
            addView(input)
        }
        AlertDialog.Builder(this)
            .setTitle(R.string.new_playlist)
            .setView(container)
            .setPositiveButton(R.string.create_playlist) { _, _ ->
                val name = input.text.toString().trim()
                when {
                    name.isEmpty() -> Toast.makeText(
                        this, R.string.playlist_name_empty, Toast.LENGTH_SHORT
                    ).show()

                    else -> {
                        val created = LocalStore.createPlaylist(this, name)
                        if (created == null) {
                            Toast.makeText(
                                this, R.string.playlist_name_exists, Toast.LENGTH_SHORT
                            ).show()
                        } else {
                            LocalStore.addToPlaylist(this, created.id, video)
                            Toast.makeText(
                                this,
                                getString(R.string.saved_to_playlist_fmt, name),
                                Toast.LENGTH_SHORT
                            ).show()
                        }
                    }
                }
            }
            .setNegativeButton(android.R.string.cancel, null)
            .show()
    }

    /** Small dim helper line used inside bottom sheets. */
    private fun hintRow(text: String): TextView = TextView(this).apply {
        this.text = text
        textSize = 13f
        setPadding(dp(4), dp(10), dp(4), dp(6))
        setTextColor(getColor(R.color.on_surface_variant))
    }

    private fun updateDownloadUi() {
        val entry = PlaybackCenter.currentEntry ?: return
        when {
            DownloadCenter.isDownloaded(this, entry.url) -> {
                binding.actionDownloadIcon.setImageResource(R.drawable.ic_check)
                binding.actionDownloadIcon.setColorFilter(getColor(R.color.music_green))
                binding.actionDownloadLabel.text = getString(R.string.downloaded_label)
            }
            DownloadCenter.hasActiveDownload(this, entry.url) -> {
                val percent = DownloadCenter.downloadProgress(this, entry.url)
                binding.actionDownloadIcon.setImageResource(R.drawable.ic_download)
                binding.actionDownloadIcon.setColorFilter(getColor(R.color.on_surface))
                binding.actionDownloadLabel.text = getString(R.string.downloading_fmt, percent)
            }
            else -> {
                binding.actionDownloadIcon.setImageResource(R.drawable.ic_download)
                binding.actionDownloadIcon.setColorFilter(getColor(R.color.on_surface))
                binding.actionDownloadLabel.text = getString(R.string.action_download)
            }
        }
    }

    private val downloadPoll = object : Runnable {
        override fun run() {
            binding.actionTimerLabel.text = com.tube1.app.ui.music.SleepTimerSheet.buttonLabel(this@PlayerActivity)
            binding.actionTimer.contentDescription = com.tube1.app.ui.music.SleepTimerSheet.accessibilityLabel(this@PlayerActivity)
            val entry = PlaybackCenter.currentEntry
            if (entry != null && !isFinishing) {
                // Keep the registry in sync with the built-in download
                // engine so a finished download flips to "Downloaded" right
                // away (jobs also self-report, this covers app restarts).
                if (DownloadCenter.hasActiveDownload(this@PlayerActivity, entry.url)) {
                    DownloadCenter.refreshStatuses(this@PlayerActivity)
                }
                updateDownloadUi()
            }
            downloadHandler.postDelayed(this, 1000)
        }
    }

    private fun toggleFavorite() {
        val nowFav = PlaybackCenter.toggleFavoriteCurrent()
        Toast.makeText(
            this,
            if (nowFav) R.string.added_to_favorites else R.string.removed_from_favorites,
            Toast.LENGTH_SHORT
        ).show()
    }

    private fun shareVideo() {
        val entry = PlaybackCenter.currentEntry ?: return
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_TEXT, entry.url)
        }
        startActivity(Intent.createChooser(intent, getString(R.string.share_via)))
    }

    private fun openChannel() {
        val entry = PlaybackCenter.currentEntry ?: return
        val channelUrl = PlaybackCenter.catalog?.uploaderUrl ?: return
        if (channelUrl.isBlank()) return
        ChannelActivity.start(this, channelUrl, entry.uploader)
    }

    private fun toggleSubscribe() {
        val entry = PlaybackCenter.currentEntry ?: return
        val channelUrl = PlaybackCenter.catalog?.uploaderUrl ?: return
        if (channelUrl.isBlank()) return
        val channelEntry = com.tube1.app.data.ChannelEntry(
            url = channelUrl,
            name = PlaybackCenter.catalog?.uploaderName ?: entry.uploader,
            avatarUrl = PlaybackCenter.catalog?.uploaderAvatarUrl.orEmpty(),
            subscriberCount = channelSubCount
        )
        val nowSubscribed = LocalStore.toggleSubscription(this, channelEntry)
        Toast.makeText(
            this,
            if (nowSubscribed) R.string.subscribed_toast else R.string.unsubscribed_toast,
            Toast.LENGTH_SHORT
        ).show()
        updateSubscribeUi()
    }

    private fun updateSubscribeUi() {
        val channelUrl = PlaybackCenter.catalog?.uploaderUrl
        if (channelUrl.isNullOrBlank()) {
            binding.subscribeButton.isVisible = false
            return
        }
        // Show it again: onCreate hides the button until the catalog loads,
        // and nothing ever set it back to visible, so it never re-appeared.
        binding.subscribeButton.isVisible = true
        val subscribed = LocalStore.isSubscribed(this, channelUrl)
        binding.subscribeButton.text = getString(if (subscribed) R.string.subscribed else R.string.subscribe)
        binding.subscribeButton.setBackgroundResource(
            if (subscribed) R.drawable.bg_subscribe_on else R.drawable.bg_subscribe_off
        )
        // The "subscribed" pill has a light background in the light theme,
        // so its label must flip to a dark color there (stays white on accent).
        binding.subscribeButton.setTextColor(
            getColor(if (subscribed) R.color.subscribe_on_text else R.color.white)
        )
    }

    private fun retry() {
        binding.errorView.isVisible = false
        PlaybackCenter.retryCurrentVideo()
    }

    // ----- Bottom sheets -----

    private fun sheetRoot(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(20), dp(16), dp(20), dp(24))
    }

    private fun sheetTitle(text: String): TextView = TextView(this).apply {
        this.text = text
        textSize = 16f
        setTextColor(getColor(R.color.on_surface))
        setTypeface(null, Typeface.BOLD)
    }

    private fun sheetRow(label: String, selected: Boolean, onClick: () -> Unit): TextView =
        TextView(this).apply {
            text = label
            textSize = 15f
            setPadding(dp(14), dp(12), dp(14), dp(12))
            setTextColor(if (selected) getColor(R.color.white) else Themes.onSurfaceColor(this@PlayerActivity))
            background = GradientDrawable().apply {
                cornerRadius = dp(10).toFloat()
                setColor(
                    if (selected) Themes.accentColor(this@PlayerActivity)
                    else Themes.elevatedColor(this@PlayerActivity)
                )
            }
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
            ).also { it.topMargin = dp(8) }
            setOnClickListener { onClick() }
        }

    /**
     * A category row for the gear menu: title on the left, the currently
     * selected value on the right and a chevron — like the official
     * YouTube player's settings menu.
     */
    private fun sheetMenuRow(mainLabel: String, valueLabel: String, onClick: () -> Unit): LinearLayout =
        LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = android.view.Gravity.CENTER_VERTICAL
            setPadding(dp(14), dp(14), dp(14), dp(14))
            background = GradientDrawable().apply {
                cornerRadius = dp(12).toFloat()
                setColor(Themes.elevatedColor(this@PlayerActivity))
            }
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
            ).also { it.topMargin = dp(10) }
            setOnClickListener { onClick() }

            addView(
                TextView(this@PlayerActivity).apply {
                    text = mainLabel
                    textSize = 15f
                    setTextColor(getColor(R.color.on_surface))
                    setTypeface(null, Typeface.BOLD)
                    layoutParams = LinearLayout.LayoutParams(
                        0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f
                    )
                }
            )
            addView(
                TextView(this@PlayerActivity).apply {
                    text = valueLabel
                    textSize = 13f
                    maxLines = 1
                    ellipsize = android.text.TextUtils.TruncateAt.END
                    setTextColor(getColor(R.color.on_surface_variant))
                    layoutParams = LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT
                    ).also { it.marginEnd = dp(6) }
                }
            )
            addView(
                android.widget.ImageView(this@PlayerActivity).apply {
                    setImageResource(R.drawable.ic_chevron_right)
                    setColorFilter(getColor(R.color.on_surface_variant))
                    importantForAccessibility = android.view.View.IMPORTANT_FOR_ACCESSIBILITY_NO
                    layoutParams = LinearLayout.LayoutParams(dp(20), dp(20))
                }
            )
        }

    private fun showSheet(sheet: BottomSheetDialog, root: LinearLayout, peekDp: Int = 420) {
        val scroll = android.widget.ScrollView(this).apply { addView(root) }
        sheet.setContentView(scroll)
        sheet.behavior.peekHeight = dp(peekDp)
        sheet.show()
    }

    /**
     * The gear menu: categories first (quality, playback speed, audio
     * track) — picking one opens its own list, like the official app.
     *
     * Quality and audio-track need the resolved stream catalog, so they only
     * exist for online playback. Downloaded videos have no catalog — they
     * used to hit the "cannot be played" gate here and the whole gear menu
     * was unusable; playback speed works everywhere, so the menu always
     * shows at least that.
     */
    private fun showVideoSettingsSheet() {
        val catalog = PlaybackCenter.catalog

        val sheet = BottomSheetDialog(this)
        val root = sheetRoot()
        root.addView(sheetTitle(getString(R.string.video_settings)))

        if (catalog != null) {
            root.addView(
                sheetMenuRow(getString(R.string.settings_quality_section), qualitySummary(catalog)) {
                    sheet.dismiss()
                    showQualitySheet()
                }
            )
        }
        root.addView(
            sheetMenuRow(getString(R.string.settings_speed_section), speedSummary()) {
                sheet.dismiss()
                showSpeedSheet()
            }
        )
        if (catalog != null && catalog.audioTracks.size > 1) {
            root.addView(
                sheetMenuRow(getString(R.string.settings_audio_track_section), audioTrackSummary(catalog)) {
                    sheet.dismiss()
                    showAudioTrackSheet()
                }
            )
        }

        showSheet(sheet, root, peekDp = 320)
    }

    private fun qualitySummary(catalog: StreamCatalog): String {
        val current = PlaybackCenter.effectiveSelectedHeight(catalog)
            ?: return getString(R.string.quality_auto_short)
        if (current == -1) return getString(R.string.quality_audio_only)
        val fps = catalog.videoOnly.firstOrNull { it.effectiveHeight() == current }?.fps
            ?: catalog.muxed.firstOrNull { it.effectiveHeight() == current }?.fps ?: 0
        return if (fps > 30) "${current}p $fps" else "${current}p"
    }

    private fun speedSummary(): String =
        if (PlaybackCenter.playbackSpeed == 1.0f) {
            getString(R.string.speed_normal)
        } else {
            "${PlaybackCenter.playbackSpeed}x"
        }

    private fun audioTrackSummary(catalog: StreamCatalog): String {
        val selected = PlaybackCenter.selectedAudioTrackId
        val track = catalog.audioTracks.firstOrNull { it.id == selected }
            ?: catalog.audioTracks.firstOrNull()
            ?: return ""
        return track.label + if (track.isOriginal) {
            " (${getString(R.string.audio_track_original)})"
        } else {
            ""
        }
    }

    private fun showQualitySheet() {
        val catalog = PlaybackCenter.catalog ?: return
        val sheet = BottomSheetDialog(this)
        val root = sheetRoot()
        root.addView(sheetTitle(getString(R.string.settings_quality_section)))

        val currentHeight = PlaybackCenter.effectiveSelectedHeight(catalog)
        root.addView(
            sheetRow(getString(R.string.quality_auto), currentHeight == null) {
                PlaybackCenter.setVideoQuality(null)
                sheet.dismiss()
            }
        )
        val useMuxed = catalog.videoOnly.isEmpty()
        val candidates = if (useMuxed) catalog.muxed else catalog.videoOnly
        candidates.forEach { v ->
            val h = v.effectiveHeight()
            val label = "${h}p" +
                (if (v.fps > 30) " ${v.fps}fps" else "") +
                (if (useMuxed) " (muxed)" else "")
            root.addView(sheetRow(label, currentHeight == h) {
                PlaybackCenter.setVideoQuality(h)
                sheet.dismiss()
            })
        }
        root.addView(
            sheetRow(getString(R.string.quality_audio_only), currentHeight == -1) {
                PlaybackCenter.setVideoQuality(-1)
                sheet.dismiss()
            }
        )
        showSheet(sheet, root)
    }

    private fun showSpeedSheet() {
        val sheet = BottomSheetDialog(this)
        val root = sheetRoot()
        root.addView(sheetTitle(getString(R.string.settings_speed_section)))

        val speeds = listOf(0.25f, 0.5f, 0.75f, 1.0f, 1.25f, 1.5f, 1.75f, 2.0f)
        val currentSpeed = PlaybackCenter.playbackSpeed
        speeds.forEach { s ->
            root.addView(
                sheetRow(
                    if (s == 1.0f) getString(R.string.speed_normal) else "${s}x",
                    s == currentSpeed
                ) {
                    PlaybackCenter.setSpeed(s)
                    sheet.dismiss()
                }
            )
        }
        showSheet(sheet, root)
    }

    private fun showAudioTrackSheet() {
        val catalog = PlaybackCenter.catalog ?: return
        val sheet = BottomSheetDialog(this)
        val root = sheetRoot()
        root.addView(sheetTitle(getString(R.string.settings_audio_track_section)))

        val currentTrack = PlaybackCenter.selectedAudioTrackId
        catalog.audioTracks.forEach { t ->
            val label = t.label + if (t.isOriginal) {
                " (${getString(R.string.audio_track_original)})"
            } else {
                ""
            }
            root.addView(
                sheetRow(label, currentTrack == t.id) {
                    PlaybackCenter.setAudioTrack(t.id)
                    Toast.makeText(
                        this,
                        getString(R.string.audio_track_switched_to, label),
                        Toast.LENGTH_SHORT
                    ).show()
                    sheet.dismiss()
                }
            )
        }
        showSheet(sheet, root)
    }

    private fun showDownloadSheet() {
        val entry = PlaybackCenter.currentEntry ?: return
        val catalog = PlaybackCenter.catalog ?: run {
            Toast.makeText(this, R.string.error_no_streams, Toast.LENGTH_SHORT).show()
            return
        }
        DownloadSheet(this, entry, catalog).show()
    }

    private fun dp(value: Int): Int = TypedValue.applyDimension(
        TypedValue.COMPLEX_UNIT_DIP, value.toFloat(), resources.displayMetrics
    ).toInt()

    companion object {
        private const val RAPID_TAP_WINDOW_MS = 900L
        private const val EXTRA_URL = "extra_url"
        private const val EXTRA_TITLE = "extra_title"
        private const val EXTRA_UPLOADER = "extra_uploader"
        private const val EXTRA_THUMB = "extra_thumb"
        private const val EXTRA_DURATION = "extra_duration"
        private const val EXTRA_ATTACH = "extra_attach"
        private const val SWIPE_MIN_DISTANCE = 130f

        fun start(context: Context, model: com.tube1.app.ui.common.VideoUiModel) {
            val intent = Intent(context, PlayerActivity::class.java).apply {
                putExtra(EXTRA_URL, model.url)
                putExtra(EXTRA_TITLE, model.title)
                putExtra(EXTRA_UPLOADER, model.uploader)
                putExtra(EXTRA_THUMB, model.thumbnailUrl)
                putExtra(EXTRA_DURATION, model.durationSec)
            }
            context.startActivity(intent)
        }

        /** Re-opens the page for whatever is already playing in the mini player. */
        fun startResume(context: Context) {
            val intent = Intent(context, PlayerActivity::class.java).apply {
                putExtra(EXTRA_ATTACH, true)
            }
            context.startActivity(intent)
        }
    }
}
